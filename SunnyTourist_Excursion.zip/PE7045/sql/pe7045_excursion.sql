-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2025 at 12:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pe7045_excursion`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingID` mediumint(8) NOT NULL,
  `excursionID` mediumint(8) NOT NULL,
  `customerID` mediumint(8) NOT NULL,
  `excursion_date` date NOT NULL,
  `num_guests` mediumint(2) NOT NULL,
  `total_booking_cost` decimal(7,2) NOT NULL,
  `booking_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingID`, `excursionID`, `customerID`, `excursion_date`, `num_guests`, `total_booking_cost`, `booking_notes`) VALUES
(1, 1, 1, '2022-10-20', 2, 140.00, NULL),
(2, 1, 2, '2025-10-01', 3, 210.00, 'available on time'),
(3, 1, 3, '2025-10-10', 2, 140.00, 'i want everything on time');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customerID` mediumint(8) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password_hash` char(255) NOT NULL,
  `customer_forename` varchar(255) NOT NULL,
  `customer_surname` varchar(255) NOT NULL,
  `customer_email` varchar(64) NOT NULL,
  `date_of_birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerID`, `username`, `password_hash`, `customer_forename`, `customer_surname`, `customer_email`, `date_of_birth`) VALUES
(1, 'fred1985', '$2y$10$qOrhpkdI0Mib.Hizs7.6A.hApiW2HfJIH/iut2Q87m/NbSJRcdbx6', 'Fred', 'Brown', 'fred@test.com', '1985-11-13'),
(2, 'uzair14', '$2y$10$kkDJ8iMILMPAhTYTycy0Je8zps0c6UrJ4jrgteiYkyBlBm70eAsFK', 'uzair', 'khan', 'ukan55663@gmail.com', '2004-07-14'),
(3, 'kongopower', '$2y$10$OnsH9FC0cZOeRgKIpf26AOgkRHm3e1TBpL43gDig6pngu66BLp/n6', 'kongo', 'power', 'ukan55663@gmail.com', '2002-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `excursions`
--

CREATE TABLE `excursions` (
  `excursionID` mediumint(8) NOT NULL,
  `excursion_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price_per_person` decimal(7,2) NOT NULL,
  `location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `excursions`
--

INSERT INTO `excursions` (`excursionID`, `excursion_name`, `description`, `price_per_person`, `location`) VALUES
(1, 'Amalfi Coast coach tour', 'Take in all the beauty of the Amalfi Coast on a day trip from Sorrento. Explore the villages of Positano, Amalfi, and Ravello during the tour.', 70.00, 'Sorrento'),
(2, 'Boat trip to Capri island', 'Full-day tour of Capri island from Sorrento. Admire views along the coast as you cruise to the island. Visit the island towns of beautiful Capri', 100.00, 'Sorrento'),
(3, 'Historical Pompeii Tour', 'Explore the ancient ruins of Pompeii, frozen in time by the eruption of Mount Vesuvius. Guided tour with expert historian.', 65.00, 'Pompeii'),
(4, 'Vesuvius Volcano Hike', 'Hike to the summit of Mount Vesuvius with an experienced guide. Breathtaking views of the Bay of Naples.', 55.00, 'Mount Vesuvius'),
(5, 'Positano Coastal Walk', 'A scenic walk along the coastline of Positano.', 35.00, 'Positano'),
(6, 'Capri Blue Grotto Boat Tour', 'A magical boat tour into the Blue Grotto sea cave.', 85.00, 'Capri'),
(7, 'Sorrento Food Tasting', 'Sample local cheeses, limoncello, and wines.', 55.00, 'Sorrento'),
(8, 'Amalfi Cathedral Tour', 'Visit the stunning Amalfi Cathedral.', 40.00, 'Almafi'),
(9, 'Ravello Gardens Visit', 'Explore the beautiful villas and gardens of Ravello.', 30.00, 'Ravello'),
(10, 'Kayaking along the Coast\r\n\r\n', 'A kayaking adventure to discover hidden beaches.', 60.00, 'Sorrento Coast'),
(11, 'Pizza Making Class', 'Learn to make authentic Neapolitan pizza.', 50.00, 'Sorrento'),
(12, 'Boat Trip to Fjords of Furore.', 'A Boat Trip to Fjords of Furore.', 75.00, 'Furore');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `excursions`
--
ALTER TABLE `excursions`
  ADD PRIMARY KEY (`excursionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingID` mediumint(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customerID` mediumint(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `excursions`
--
ALTER TABLE `excursions`
  MODIFY `excursionID` mediumint(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
