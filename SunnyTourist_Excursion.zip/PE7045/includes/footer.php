    </main>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> Sunny Tours. All rights reserved.</p>
    </footer>
</body>
</html>