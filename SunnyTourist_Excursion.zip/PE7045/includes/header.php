<?php
// Check if user is logged in
$isLoggedIn = isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sunny Tours - Excursion Booking System</title>
    <link rel="stylesheet" href="../assets/stylesheets/style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <h1>Sunny Tours</h1>
            </div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="excursions.php">Excursions</a></li>
                <?php if ($isLoggedIn): ?>
                    <li><a href="my-bookings.php">My Bookings</a></li>
                    <li><a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION["username"]); ?>)</a></li>
                <?php else: ?>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
                <li><a href="credits.php">Credits</a></li>
            </ul>
        </nav>
    </header>
    <main>