<?php
// Authentication and security functions

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;
}

/**
 * Redirect to login if not authenticated
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header("location: login.php");
        exit;
    }
}

/**
 * Redirect to homepage if already logged in
 */
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        header("location: index.php");
        exit;
    }
}

/**
 * Validate email format
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Sanitize input data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Generate CSRF token
 */
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate CSRF token
 */
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Check if user owns a booking
 */
function userOwnsBooking($bookingId) {
    global $pdo;
    
    if (!isLoggedIn()) return false;
    
    try {
        $sql = "SELECT customerID FROM booking WHERE bookingID = :booking_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(":booking_id", $bookingId, PDO::PARAM_INT);
        $stmt->execute();
        
        if ($stmt->rowCount() == 1) {
            $booking = $stmt->fetch();
            return $booking['customerID'] == $_SESSION["id"];
        }
        return false;
    } catch(PDOException $e) {
        return false;
    }
}
?>