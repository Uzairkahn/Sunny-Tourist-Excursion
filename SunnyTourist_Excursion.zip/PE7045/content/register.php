<?php
require_once('../includes/config.php');

// Check if user is already logged in, redirect to homepage
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}

// Define variables and initialize with empty values
$username = $password = $confirm_password = $forename = $surname = $email = $dob = "";
$username_err = $password_err = $confirm_password_err = $forename_err = $surname_err = $email_err = $dob_err = "";

// Process form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        // Check if username already exists
        $sql = "SELECT customerID FROM customers WHERE username = :username";
        
        if($stmt = $pdo->prepare($sql)){
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            $param_username = trim($_POST["username"]);
            
            if($stmt->execute()){
                if($stmt->rowCount() == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Validate forename
    if(empty(trim($_POST["forename"]))){
        $forename_err = "Please enter your first name.";
    } else{
        $forename = trim($_POST["forename"]);
    }
    
    // Validate surname
    if(empty(trim($_POST["surname"]))){
        $surname_err = "Please enter your last name.";
    } else{
        $surname = trim($_POST["surname"]);
    }
    
    // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter your email.";
    } else if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)){
        $email_err = "Please enter a valid email address.";
    } else{
        $email = trim($_POST["email"]);
    }
    
    // Validate date of birth
    if(empty(trim($_POST["dob"]))){
        $dob_err = "Please enter your date of birth.";
    } else{
        $dob = trim($_POST["dob"]);
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && 
       empty($forename_err) && empty($surname_err) && empty($email_err) && empty($dob_err)){
        
        // Prepare insert statement
        $sql = "INSERT INTO customers (username, password_hash, customer_forename, customer_surname, customer_email, date_of_birth) 
                VALUES (:username, :password_hash, :forename, :surname, :email, :dob)";
         
        if($stmt = $pdo->prepare($sql)){
            // Bind parameters
            $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
            $stmt->bindParam(":password_hash", $param_password, PDO::PARAM_STR);
            $stmt->bindParam(":forename", $param_forename, PDO::PARAM_STR);
            $stmt->bindParam(":surname", $param_surname, PDO::PARAM_STR);
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $stmt->bindParam(":dob", $param_dob, PDO::PARAM_STR);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Hash password
            $param_forename = $forename;
            $param_surname = $surname;
            $param_email = $email;
            $param_dob = $dob;
            
            // Attempt to execute
            if($stmt->execute()){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
            unset($stmt);
        }
    }
    unset($pdo);
}

require_once('../includes/header.php');
?>

<div style="max-width: 600px; margin: 0 auto; padding: 20px;">
    <h2>Create Account</h2>
    <p>Please fill this form to register.</p>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
            <span style="color: red;"><?php echo $username_err; ?></span>
        </div>
        
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
            <span style="color: red;"><?php echo $password_err; ?></span>
        </div>
        
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
            <span style="color: red;"><?php echo $confirm_password_err; ?></span>
        </div>
        
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="forename" class="form-control <?php echo (!empty($forename_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $forename; ?>">
            <span style="color: red;"><?php echo $forename_err; ?></span>
        </div>
        
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="surname" class="form-control <?php echo (!empty($surname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $surname; ?>">
            <span style="color: red;"><?php echo $surname_err; ?></span>
        </div>
        
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
            <span style="color: red;"><?php echo $email_err; ?></span>
        </div>
        
        <div class="form-group">
            <label>Date of Birth</label>
            <input type="date" name="dob" class="form-control <?php echo (!empty($dob_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $dob; ?>">
            <span style="color: red;"><?php echo $dob_err; ?></span>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn">Register</button>
            <button type="reset" class="btn" style="background-color: #666;">Reset</button>
        </div>
        
        <p>Already have an account? <a href="login.php">Login here</a>.</p>
    </form>
</div>

<?php
require_once('../includes/footer.php');
?>