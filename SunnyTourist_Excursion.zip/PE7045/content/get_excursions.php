<?php
require_once('../includes/config.php');

header('Content-Type: application/json');

try {
    $sql = "SELECT * FROM excursions ORDER BY excursionID";
    $stmt = $pdo->query($sql);
    $excursions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($excursions);
} catch(PDOException $e) {
    echo json_encode([]);
}
?>