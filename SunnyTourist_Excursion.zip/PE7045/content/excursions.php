<?php
require_once('../includes/config.php');
require_once('../includes/header.php');
?>

<h2>All Excursions</h2>

<div class="excursion-grid">
    <?php
    try {
        // Fetch all excursions from database
        $sql = "SELECT * FROM excursions ORDER BY excursion_name";
        $stmt = $pdo->query($sql);
        // REPLACE the existing while loop with this NEW code:

if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $imagePath = "../assets/images/excursion" . $row['excursionID'] . ".jpg";
        
        echo '<div class="excursion-card">';
        echo '<div style="height: 200px; overflow: hidden;">';
        echo '<img src="' . $imagePath . '" alt="' . htmlspecialchars($row['excursion_name']) . '" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.style.backgroundColor=\'#3498db\'; this.style.display=\'flex\'; this.style.alignItems=\'center\'; this.style.justifyContent=\'center\'; this.innerHTML=\'Image<br>Not Found\'">';
        echo '</div>';
        echo '<div class="excursion-card-content">';
        echo '<h3>' . htmlspecialchars($row['excursion_name']) . '</h3>';
        echo '<p>' . htmlspecialchars(substr($row['description'], 0, 100)) . '...</p>';
        echo '<p class="price">£' . htmlspecialchars($row['price_per_person']) . ' per person</p>';
        echo '<p><strong>Location:</strong> ' . htmlspecialchars($row['location']) . '</p>';
        
        // View Details button
        echo '<a href="excursion-details.php?id=' . $row['excursionID'] . '" class="btn" style="margin-top: 10px;">View Details & Book</a>';
        
        echo '</div>';
        echo '</div>';
    }
} else {
    echo '<p>No excursions found.</p>';
}
    } catch(PDOException $e) {
        echo '<div class="alert-error">Error loading excursions: ' . $e->getMessage() . '</div>';
    }
    ?>
</div>

<?php
require_once('../includes/footer.php');
?>