<?php
require_once('../includes/config.php');
require_once('../includes/header.php');

// Check if excursion ID is provided
if(!isset($_GET['id']) || empty($_GET['id'])){
    header("location: excursions.php");
    exit;
}

// Get excursion details
$excursion_id = $_GET['id'];
$excursion = [];
$isLoggedIn = isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;

try {
    $sql = "SELECT * FROM excursions WHERE excursionID = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id", $excursion_id, PDO::PARAM_INT);
    $stmt->execute();
    
    if($stmt->rowCount() == 1){
        $excursion = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        header("location: excursions.php");
        exit;
    }
} catch(PDOException $e) {
    echo '<div class="alert-error">Error loading excursion details.</div>';
}
?>

<div style="max-width: 800px; margin: 0 auto;">
    <?php if(!empty($excursion)): ?>
        <?php
        // YEH NAYA CODE ADD KAREIN - Image ka path banayein
        $imagePath = "../assets/images/excursion" . $excursion['excursionID'] . ".jpg";
        ?>
        
        <!-- YEH PURANA BLUE BOX HATAYEIN -->
        <!-- <div style="background-color: #2980b9; height: 300px; display: flex; align-items: center; justify-content: center; color: white; margin-bottom: 20px;">
            <h1 style="font-size: 2.5em;"><?php echo htmlspecialchars($excursion['excursion_name']); ?></h1>
        </div> -->
        
        <!-- YEH NAYA IMAGE CODE ADD KAREIN -->
        <div style="height: 300px; overflow: hidden; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
            <img src="<?php echo $imagePath; ?>" 
                 alt="<?php echo htmlspecialchars($excursion['excursion_name']); ?>" 
                 style="width: 100%; height: 100%; object-fit: cover;"
                 onerror="this.style.backgroundColor='#3498db'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.innerHTML='<span style=color:white;font-weight:bold;>Image Not Found</span>'">
        </div>
        
        <!-- Page Title -->
        <h1 style="text-align: center; margin-bottom: 30px; color: #2c3e50;"><?php echo htmlspecialchars($excursion['excursion_name']); ?></h1>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px;">
            <div>
                <h3>Excursion Details</h3>
                <p><strong>Description:</strong><br><?php echo htmlspecialchars($excursion['description']); ?></p>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($excursion['location']); ?></p>
            </div>
            
            <div>
                <h3>Pricing & Booking</h3>
                <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px;">
                    <p class="price" style="font-size: 1.5em;">£<?php echo htmlspecialchars($excursion['price_per_person']); ?> per person</p>
                    
                    <?php if($isLoggedIn): ?>
                        <a href="booking.php?excursion_id=<?php echo $excursion['excursionID']; ?>" class="btn" style="background-color: #27ae60; display: block; text-align: center; margin-top: 15px;">
                            Book Now
                        </a>
                    <?php else: ?>
                        <p style="color: #e74c3c; margin-top: 15px;">
                            Please <a href="login.php">login</a> to book this excursion.
                        </p>
                        <a href="login.php" class="btn" style="display: block; text-align: center; margin-top: 10px;">
                            Login to Book
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
    <?php else: ?>
        <div class="alert-error">Excursion not found.</div>
        <a href="excursions.php" class="btn">Back to Excursions</a>
    <?php endif; ?>
</div>

<?php
require_once('../includes/footer.php');
?>