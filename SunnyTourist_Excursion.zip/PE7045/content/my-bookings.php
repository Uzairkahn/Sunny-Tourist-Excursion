<?php
require_once('../includes/config.php');

// Check if user is logged in, if not redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

$bookings = [];

// Get user's bookings
try {
    $sql = "SELECT b.*, e.excursion_name, e.location, e.price_per_person 
            FROM booking b 
            JOIN excursions e ON b.excursionID = e.excursionID 
            WHERE b.customerID = :customer_id 
            ORDER BY b.excursion_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":customer_id", $_SESSION["id"], PDO::PARAM_INT);
    $stmt->execute();
    
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Error loading bookings.";
}

require_once('../includes/header.php');
?>

<div class="bookings-container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
    <h2 style="text-align: center; margin-bottom: 10px; color: #2c3e50;">My Bookings</h2>
    <p style="text-align: center; margin-bottom: 40px; color: #7f8c8d;">Welcome back, <?php echo htmlspecialchars($_SESSION["forename"]); ?>! Here's your booking history.</p>
    
    <?php if(isset($error)): ?>
        <div class="alert-error" style="text-align: center;"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if(count($bookings) > 0): ?>
        <div class="bookings-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 25px;">
            <?php foreach($bookings as $booking): 
                $imagePath = "../assets/images/excursion" . $booking['excursionID'] . ".jpg";
                $bookingDate = new DateTime($booking['excursion_date']);
                $isPastBooking = $bookingDate < new DateTime();
            ?>
            <div class="booking-card" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 6px 20px rgba(0,0,0,0.1); transition: transform 0.3s ease, box-shadow 0.3s ease;">
                <!-- Booking Header with Status -->
                <div style="background: <?php echo $isPastBooking ? '#95a5a6' : '#27ae60'; ?>; padding: 15px 20px; color: white; display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: bold; font-size: 0.9em;">
                        #<?php echo $booking['bookingID']; ?>
                    </span>
                    <span style="background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 0.8em;">
                        <?php echo $isPastBooking ? 'COMPLETED' : 'UPCOMING'; ?>
                    </span>
                </div>
                
                <!-- Excursion Image -->
                <div style="height: 180px; overflow: hidden;">
                    <img src="<?php echo $imagePath; ?>" 
                         alt="<?php echo htmlspecialchars($booking['excursion_name']); ?>" 
                         style="width: 100%; height: 100%; object-fit: cover;"
                         onerror="this.style.backgroundColor='#3498db'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.innerHTML='<span style=color:white;font-weight:bold;>Image Not Found</span>'">
                </div>
                
                <!-- Booking Details -->
                <div style="padding: 20px;">
                    <h3 style="margin: 0 0 10px 0; color: #2c3e50; font-size: 1.2em;">
                        <?php echo htmlspecialchars($booking['excursion_name']); ?>
                    </h3>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                        <div>
                            <p style="margin: 0; font-size: 0.9em; color: #7f8c8d;">Date</p>
                            <p style="margin: 0; font-weight: bold; color: #2c3e50;">
                                <?php echo date('d M Y', strtotime($booking['excursion_date'])); ?>
                            </p>
                        </div>
                        
                        <div>
                            <p style="margin: 0; font-size: 0.9em; color: #7f8c8d;">Guests</p>
                            <p style="margin: 0; font-weight: bold; color: #2c3e50;">
                                <?php echo $booking['num_guests']; ?> guest<?php echo $booking['num_guests'] > 1 ? 's' : ''; ?>
                            </p>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                        <div>
                            <p style="margin: 0; font-size: 0.9em; color: #7f8c8d;">Location</p>
                            <p style="margin: 0; font-weight: bold; color: #2c3e50;">
                                <?php echo htmlspecialchars($booking['location']); ?>
                            </p>
                        </div>
                        
                        <div>
                            <p style="margin: 0; font-size: 0.9em; color: #7f8c8d;">Price per person</p>
                            <p style="margin: 0; font-weight: bold; color: #2c3e50;">
                                £<?php echo number_format($booking['price_per_person'], 2); ?>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Total Cost -->
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center;">
                        <p style="margin: 0; font-size: 0.9em; color: #7f8c8d;">Total Amount Paid</p>
                        <p style="margin: 0; font-weight: bold; color: #27ae60; font-size: 1.3em;">
                            £<?php echo number_format($booking['total_booking_cost'], 2); ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 60px 40px; background-color: #f8f9fa; border-radius: 12px; margin-top: 30px;">
            <div style="font-size: 4em; color: #bdc3c7; margin-bottom: 20px;">✈️</div>
            <h3 style="color: #2c3e50; margin-bottom: 15px;">No bookings yet!</h3>
            <p style="color: #7f8c8d; margin-bottom: 30px; max-width: 400px; margin-left: auto; margin-right: auto;">
                You haven't made any bookings yet. Start exploring our amazing excursions and plan your next adventure!
            </p>
            <a href="excursions.php" class="btn" style="background-color: #3498db; padding: 12px 30px; font-size: 1.1em;">Browse Excursions</a>
        </div>
    <?php endif; ?>
</div>

<style>
    .booking-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 30px rgba(0,0,0,0.15);
    }
    
    @media (max-width: 768px) {
        .bookings-grid {
            grid-template-columns: 1fr !important;
        }
    }
</style>

<?php
require_once('../includes/footer.php');
?>