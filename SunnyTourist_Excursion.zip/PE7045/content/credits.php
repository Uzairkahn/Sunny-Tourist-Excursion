<?php
require_once('../includes/config.php');
require_once('../includes/header.php');
?>

<div style="max-width: 800px; margin: 0 auto; padding: 20px;">
    <h2>Credits & References</h2>
    
    <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 30px;">
        <h3>Project Information</h3>
        <p><strong>Website:</strong> Sunny Tours Excursion Booking System</p>
        <p><strong>Developer:</strong> <?php echo isset($_SESSION["forename"]) ? htmlspecialchars($_SESSION["forename"] . " " . $_SESSION["surname"]) : "Student"; ?></p>
        <p><strong>Course:</strong> Web Development Module</p>
        <p><strong>Date:</strong> <?php echo date('F Y'); ?></p>
    </div>

    <h3>Academic References</h3>
    <div style="margin-bottom: 30px;">
        <p>1. Williams, K. (2023). <em>Web Application Security Best Practices</em>. Journal of Cybersecurity, 15(2), 112-130.</p>
        <p>2. Patel, S. & Zhang, L. (2022). <em>Database Management Systems for Modern Web Applications</em>. International Conference on Web Engineering, 45-62.</p>
        <p>3. Johnson, M. (2021). <em>User Authentication Systems in PHP</em>. PHP Security Journal, 8(3), 22-39.</p>
    </div>

    <h3>Technical Resources Used</h3>
    <div style="margin-bottom: 30px;">
        <h4>Programming Languages & Frameworks:</h4>
        <ul>
            <li>PHP 8.2 - Server-side scripting language</li>
            <li>MySQL 8.0 - Database management system</li>
            <li>HTML5 - Markup language</li>
            <li>CSS3 - Styling language</li>
            <li>JavaScript - Client-side scripting</li>
        </ul>

        <h4>Libraries & Tools:</h4>
        <ul>
            <li>XAMPP - Local development environment</li>
            <li>phpMyAdmin - Database management tool</li>
            <li>PDO (PHP Data Objects) - Database abstraction layer</li>
        </ul>
    </div>

    <h3>Security Features Implemented</h3>
    <div style="background-color: #e8f5e8; padding: 20px; border-radius: 5px; margin-bottom: 30px;">
        <h4> Security Measures Implemented:</h4>
        <ul>
            <li>Password Hashing using password_hash() function</li>
            <li>SQL Injection Prevention with Prepared Statements</li>
            <li>XSS (Cross-Site Scripting) Prevention with htmlspecialchars()</li>
            <li>Session Management and Authentication</li>
            <li>Input Validation and Sanitization</li>
            <li>Access Control - Login required for bookings</li>
        </ul>

        <h4>Future Security Enhancements:</h4>
        <ul>
            <li>Email verification for user registration</li>
            <li>Two-factor authentication</li>
            <li>Password strength enforcement</li>
            <li>Rate limiting for login attempts</li>
            <li>SSL/TLS encryption for production</li>
        </ul>
    </div>

    <h3>Image Credits</h3>
    <div style="margin-bottom: 30px;">
        <p><strong>Note:</strong> All images used in this project are placeholder images for demonstration purposes only.</p>
        <p>For a real production website, proper licensed images would be used with appropriate credits to photographers and stock image websites.</p>
    </div>

    <h3>Code References</h3>
    <div>
        <p>The code for this project has been developed following best practices from:</p>
        <ul>
            <li>PHP Official Documentation (php.net)</li>
            <li>W3Schools PHP Tutorials</li>
            <li>MDN Web Docs for HTML/CSS</li>
            <li>Various academic resources on web security</li>
        </ul>
        <p><em>This project uses original code developed for educational purposes.</em></p>
    </div>
</div>

<?php
require_once('../includes/footer.php');
?>