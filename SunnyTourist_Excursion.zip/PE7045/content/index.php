<?php
require_once('../includes/config.php');
require_once('../includes/header.php');
?>

<!-- link to the new CSS (adjust path if needed) -->
<link rel="stylesheet" href="../assets/css/excursions.css">

<?php

// Define image paths for each excursion (fallback/local mapping)

?>

<section class="hero" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('../assets/images/hero background.jpg'); background-size: cover; padding: 100px 0; text-align: center; color: white;">
    <h2 style="font-size: 2.5em; margin-bottom: 20px;">Discover Amazing Excursions</h2>
    <p style="font-size: 1.2em; margin-bottom: 30px;">Explore beautiful destinations with our curated day trips</p>
    <a href="excursions.php" class="btn" style="background-color: #f39c12; padding: 10px 20px; text-decoration: none; color: white; border-radius: 4px; display: inline-block;">Browse Excursions</a>
</section>

<!-- Featured excursions (updated) -->
<section class="featured-excursions" style="padding: 50px 0; background-color: #f8f9fa; position: relative;">
  <div class="container" style="width: 90%; max-width: 1200px; margin: 0 auto; position: relative;">
    <h2 class="text-center" style="text-align: center; margin-bottom: 40px; font-size: 2em; color: #333;">Popular Excursions</h2>

    <!-- Navigation wrapper (arrows + page info) -->
    <div class="nav-wrapper" style="position: relative; display: flex; justify-content: center; align-items: center; margin-bottom: 30px;">
     
    <!-- Left Arrow -->
     <button id="prevBtn" onclick="showPrevExcursions()" aria-label="Previous excursions"
        class="circle-arrow left-arrow"
        style="position: absolute; left: -48px; top: 50%; transform: translateY(-50%); background: #2c3e50; color: white; border: none; border-radius: 50%; width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 20px; box-shadow: 0 6px 18px rgba(0,0,0,0.15); z-index: 20;">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>

      <!-- Page Info -->
      <span id="page-info" style="font-weight: bold; font-size: 1.1em; background: #f39c12; color: white; padding: 8px 16px; border-radius: 20px; z-index: 10;">Page 1 of 1</span>

      <!-- Right Arrow -->
      <button id="nextBtn" onclick="showNextExcursions()" aria-label="Next excursions"
              class="circle-arrow right-arrow"
              style="position: absolute; right: -48px; top: 50%; transform: translateY(-50%); background: #2c3e50; color: white; border: none; border-radius: 50%; width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 20px; box-shadow: 0 6px 18px rgba(0,0,0,0.15); z-index: 20;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </div>

    <div class="excursion-grid" id="excursion-container">
      <!-- Excursions loaded by JS -->
    </div>
  </div>
</section>

<!-- JS: improved and matching HTML structure (no changes needed to your get_excursions.php) -->
<script>
  let currentPage = 1;
  const excursionsPerPage = 3;
  let allExcursions = [];

  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const pageInfo = document.getElementById('page-info');
  const container = document.getElementById('excursion-container');

  // fetch excursions (your existing endpoint)
  fetch('get_excursions.php')
    .then(res => res.json())
    .then(data => {
      allExcursions = Array.isArray(data) ? data : [];
      showExcursions(currentPage);
    })
    .catch(err => {
      console.error('Error loading excursions:', err);
      container.innerHTML = '<p style="color:#777;">Unable to load excursions right now.</p>';
      updateControls();
    });

  function showExcursions(page) {
    const startIndex = (page - 1) * excursionsPerPage;
    const pageExcursions = allExcursions.slice(startIndex, startIndex + excursionsPerPage);

    const maxPage = Math.max(1, Math.ceil(allExcursions.length / excursionsPerPage));
    pageInfo.textContent = `Page ${page} of ${maxPage}`;

    container.innerHTML = '';

    pageExcursions.forEach(excursion => {
      const excursionKey = `excursion${excursion.excursionID}`;
      const imagePath = `../assets/images/${excursionKey}.jpg`;

      const card = document.createElement('div');
      card.className = 'excursion-card';

      // NOTE: we add class="excursion-card-content" so CSS applies
      card.innerHTML = `
        <div style="height:220px; overflow:hidden;">
          <img src="${imagePath}" alt="${escapeHtml(excursion.excursion_name)}" onerror="this.src='../assets/images/placeholder.jpg'">
        </div>
        <div class="excursion-card-content" style="padding:18px; display:flex; flex-direction:column; gap:10px; flex:1;">
          <div>
            <h3 style="margin:0; color:#2c3e50; font-size:1.05rem;">${escapeHtml(excursion.excursion_name)}</h3>
            <p style="color:#7f8c8d; line-height:1.4; margin:8px 0 0 0;">${escapeHtml(excursion.description ? excursion.description.substring(0, 100) : '')}...</p>
          </div>

          <div style="margin-top:12px; display:flex; justify-content:space-between; align-items:center; gap:10px;">
            <p style="font-weight:700; color:#e74c3c; margin:0;">£${escapeHtml(String(excursion.price_per_person || '0'))} per person</p>
            <a href="excursion-details.php?id=${escapeHtml(String(excursion.excursionID))}" class="btn excursion-btn" style="background-color:#3498db; color:white; padding:8px 12px; text-decoration:none; border-radius:4px;">View Details</a>
          </div>
        </div>
      `;
      container.appendChild(card);
    });

    updateControls();
  }

  function showNextExcursions() {
    const maxPage = Math.ceil(allExcursions.length / excursionsPerPage);
    if (currentPage < maxPage) {
      currentPage++;
      showExcursions(currentPage);
    }
  }

  function showPrevExcursions() {
    if (currentPage > 1) {
      currentPage--;
      showExcursions(currentPage);
    }
  }

  function updateControls() {
    const maxPage = Math.max(1, Math.ceil(allExcursions.length / excursionsPerPage));
    prevBtn.disabled = currentPage <= 1;
    nextBtn.disabled = currentPage >= maxPage;
    pageInfo.textContent = `Page ${currentPage} of ${maxPage}`;
  }

  // Small XSS-safe helper
  function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // keyboard accessibility: left/right arrow keys
  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') showNextExcursions();
    if (e.key === 'ArrowLeft') showPrevExcursions();
  });
</script>
