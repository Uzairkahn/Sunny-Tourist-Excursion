<?php
require_once('../includes/config.php');

// Check if user is logged in, if not redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Check if excursion_id is provided
if(!isset($_GET['excursion_id']) || empty($_GET['excursion_id'])){
    header("location: excursions.php");
    exit;
}

$excursion_id = $_GET['excursion_id'];
$excursion = [];
$booking_success = false;
$booking_error = "";

// Get excursion details
try {
    $sql = "SELECT * FROM excursions WHERE excursionID = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":id", $excursion_id, PDO::PARAM_INT);
    $stmt->execute();
    
    if($stmt->rowCount() == 1){
        $excursion = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        header("location: excursions.php");
        exit;
    }
} catch(PDOException $e) {
    $booking_error = "Error loading excursion details.";
}

// Process booking form
if($_SERVER["REQUEST_METHOD"] == "POST" && !empty($excursion)){
    $excursion_date = trim($_POST["excursion_date"]);
    $num_guests = trim($_POST["num_guests"]);
    $booking_notes = trim($_POST["booking_notes"]);
    
    // Validate inputs
    if(empty($excursion_date)){
        $booking_error = "Please select a date for the excursion.";
    } elseif(empty($num_guests) || $num_guests < 1 || $num_guests > 20){
        $booking_error = "Please enter a valid number of guests (1-20).";
    } else {
        // Calculate total cost
        $total_cost = $num_guests * $excursion['price_per_person'];
        $booking_id = 0;
        // Insert booking into database
        try {
            $sql = "INSERT INTO booking (excursionID, customerID, excursion_date, num_guests, total_booking_cost, booking_notes) 
                    VALUES (:excursion_id, :customer_id, :excursion_date, :num_guests, :total_cost, :booking_notes)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(":excursion_id", $excursion_id, PDO::PARAM_INT);
            $stmt->bindParam(":customer_id", $_SESSION["id"], PDO::PARAM_INT);
            $stmt->bindParam(":excursion_date", $excursion_date, PDO::PARAM_STR);
            $stmt->bindParam(":num_guests", $num_guests, PDO::PARAM_INT);
            $stmt->bindParam(":total_cost", $total_cost, PDO::PARAM_STR);
            $stmt->bindParam(":booking_notes", $booking_notes, PDO::PARAM_STR);
            
            if($stmt->execute()){
                $booking_success = true;
                $booking_id = $pdo->lastInsertId();
            } else {
                $booking_error = "Error creating booking. Please try again.";
            }
        } catch(PDOException $e) {
            $booking_error = "Database error: " . $e->getMessage();
        }
    }
}

require_once('../includes/header.php');
?>

<div style="max-width: 800px; margin: 0 auto; padding: 20px;">
    <?php if(!empty($excursion)): ?>
        
        <?php if($booking_success): ?>
            <div class="alert-success">
                <h3>✅ Booking Confirmed!</h3>
                <p>Your booking for <strong><?php echo htmlspecialchars($excursion['excursion_name']); ?></strong> has been successfully confirmed.</p>
                <p><strong>Booking Reference:</strong> #<?php echo $booking_id; ?></p>
                <p><strong>Date:</strong> <?php echo htmlspecialchars($excursion_date); ?></p>
                <p><strong>Number of Guests:</strong> <?php echo htmlspecialchars($num_guests); ?></p>
                <p><strong>Total Cost:</strong> £<?php echo number_format($total_cost, 2); ?></p>
                
                <div style="margin-top: 20px;">
                    <a href="my-bookings.php" class="btn">View My Bookings</a>
                    <a href="excursions.php" class="btn" style="background-color: #3498db;">Book Another Excursion</a>
                </div>
            </div>
        <?php else: ?>
            <h2>Book: <?php echo htmlspecialchars($excursion['excursion_name']); ?></h2>
            
            <?php if(!empty($booking_error)): ?>
                <div class="alert-error"><?php echo $booking_error; ?></div>
            <?php endif; ?>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 20px;">
                <div>
                    <h3>Excursion Details</h3>
                    <p><strong>Description:</strong><br><?php echo htmlspecialchars($excursion['description']); ?></p>
                    <p><strong>Location:</strong> <?php echo htmlspecialchars($excursion['location']); ?></p>
                    <p><strong>Price per person:</strong> £<?php echo htmlspecialchars($excursion['price_per_person']); ?></p>
                </div>
                
                <div>
                    <h3>Booking Information</h3>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?excursion_id=' . $excursion_id; ?>" method="post">
                        <div class="form-group">
                            <label>Excursion Date *</label>
                            <input type="date" name="excursion_date" required 
                                   min="<?php echo date('Y-m-d'); ?>" 
                                   class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label>Number of Guests *</label>
                            <select name="num_guests" required class="form-control">
                                <option value="">Select guests</option>
                                <?php for($i = 1; $i <= 20; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?> guest<?php echo $i > 1 ? 's' : ''; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Special Requests/Notes</label>
                            <textarea name="booking_notes" rows="3" class="form-control" 
                                      placeholder="Any special requirements or notes..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn" style="background-color: #27ae60;">Confirm Booking</button>
                            <a href="excursion-details.php?id=<?php echo $excursion_id; ?>" class="btn" style="background-color: #95a5a6;">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
        
    <?php else: ?>
        <div class="alert-error">Excursion not found.</div>
        <a href="excursions.php" class="btn">Back to Excursions</a>
    <?php endif; ?>
</div>

<?php
require_once('../includes/footer.php');
?>